<html>
   <head>
      <title>esempio php richiamato da Ajax</title>
   </head>
   <body>

        <?php 
        echo "Questo testo e' scritto da <b>PHP<b>";
        ?>
   </body>
</html>
